/***********************************************************************************
cs1713p5.c by Christian Wilson
**********************************************************************/
// If compiling using visual studio, tell the compiler not to give its warnings
// about the safety of scanf and printf
#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "cs1713p5.h"

/******************** insertT ******************************************/
NodeT *insertT(NodeT *p, Flight flight)
{ 
    /**** your code ******/
	
	if(p == NULL)
		return allocateNodeT(flight);
	
	//don't allow duplicates
	if(strcmp(flight.szFlightId, p->flight.szFlightId) == 0) {
		return p;
	}
	
	//if new value is < p's value, look left
	//re-assign left child with whatever next call to insertT returns
	if(strcmp(flight.szFlightId, p->flight.szFlightId) < 0) {
		p->pLeft = insertT(p->pLeft, flight);
	} else {
		//otherwise, re-assign right child with whatever next call to insertT returns
		p->pRight = insertT(p->pRight, flight);
	}
	
	//important for fall-through to return the paramter p so that caller will re-assign left or right
	//to its original left or right child
	return p; 

}

/******************** printFlights ***************************************/
void printFlightsHelper(NodeT *pRoot) 
{ 
	//can't go any further so return
        if(pRoot == NULL)
                return;

	//go right as far as possible
	printFlightsHelper(pRoot->pLeft); 

	//print out flight info
        printf("    %-10s   %-4s %-4s %-6s %5d   $%5.2lf\n"
            , pRoot->flight.szFlightId
            , pRoot->flight.szFrom
            , pRoot->flight.szDest
            , pRoot->flight.szDepartTm
            , pRoot->flight.iAvailSeatCnt
            , pRoot->flight.dSeatPrice);

	//go left as far as possible
	printFlightsHelper(pRoot->pRight);
}

void printFlights(char *pszHeading, NodeT *pRoot){

	printf("%s\n", pszHeading);
    	printf("    %-10s   %-4s %-4s %-6s %-6s %-10s\n"
        , "Flight Id", "From", "Dest", "Depart", "Avail", "Unit Price");

        printFlightsHelper(pRoot);
}

/**************************** prettyPrintT ********************************/
void prettyPrintT(NodeT * p, int indent) {

	//can't go any further to right or left, so return
	if(p == NULL)
		return;
	
	//go right as far as possible
	prettyPrintT(p->pRight, indent + 1); 
	
	//print the node. indent is based on p's level in the tree
	//notice the use of a variable for the width specifier
	int i;
	for(i = 0; i < indent; i++) {
	printf("   ");
	}
	printf("%*s\n", indent, p->flight.szFlightId); 


	//go left as far as possible
	prettyPrintT(p->pLeft, indent + 1);
}

/********************processCustomerCommand ******************************/
void processCustomerCommand(NodeT **ppRoot
    , char *pszSubCommand, char *pszRemainingInput
    , Customer *pCustomer, double *pdCustomerRequestTotalCost)
{ 
    int iScanfCnt;
    FlightRequest flightRequest;

   // Determine what to do based on the subCommand
    if (strcmp(pszSubCommand, "BEGIN") == 0)
    {
        // get the Customer Identification Information
        // your code
	iScanfCnt = sscanf(pszRemainingInput, "%c %11s %51s %31[^\n]\n"
			, &pCustomer->cGender
			, pCustomer->szBirthDt
			, pCustomer->szEmailAddr
			, pCustomer->szFullName);
			
        if (iScanfCnt < 4)
            exitError(ERR_CUSTOMER_ID_DATA, pszRemainingInput);

    }
    else if (strcmp(pszSubCommand, "COMPLETE") == 0)
    {        
	printf("\t\t\t\t\t\t TOTAL COST: $%5.2lf\n", *pdCustomerRequestTotalCost);
	*pdCustomerRequestTotalCost = 0;
	printf("*************************************************************\n");
    }
    else if (strcmp(pszSubCommand, "ADDRESS") == 0)
    {
        // get the postal address 
        // your code 
	iScanfCnt = sscanf(pszRemainingInput,"%31[^,],%21[^,],%3[^,],%6s\n"
			, pCustomer->szStreetAddress
			, pCustomer->szCity
			, pCustomer->szStateCd
			, pCustomer->szZipCd);

	printf("********************  FLIGHT RESERVATION REQUEST  *******************\n");

	printf("%s %s (%c %s)\n"
			, pCustomer->szEmailAddr
			, pCustomer->szFullName
			, pCustomer->cGender
			, pCustomer->szBirthDt);
        
        printf("%s\n", pCustomer->szStreetAddress);
        
        printf("%s, %s %s\n", pCustomer->szCity
               , pCustomer->szStateCd
               , pCustomer->szZipCd);

        printf("\t\t\t\t%-10s %8s %10s %8s\n"
            , "Flight Id"
            , "Quantity"
            , "Unit Price"
            , "Cost");
    }
    else if (strcmp(pszSubCommand, "REQUEST") == 0)
    {
        // get a flight request
        // your code
        iScanfCnt = sscanf(pszRemainingInput,"%11s %5d"
			, flightRequest.szFlightId
			, &flightRequest.iRequestSeats);
		

        // find the flight in the array
	NodeT * new = searchT(*ppRoot, flightRequest.szFlightId);

        // your code  
        if(new == NULL) {
            printf("\t\t\t\t%-10s %8d *** %s\n"
                   , flightRequest.szFlightId
                   , flightRequest.iRequestSeats, ERR_FLIGHT_NOT_FOUND);
        } 
	else {
	
        double cost = new->flight.dSeatPrice * flightRequest.iRequestSeats;
            printf("\t\t\t\t%-10s %8d $%5.2lf $%5.2lf\n"
                   , flightRequest.szFlightId
                   , flightRequest.iRequestSeats
                   , new->flight.dSeatPrice
                   , cost);
	*pdCustomerRequestTotalCost += cost;
	}  
    }
    else printf("   *** %s %s\n", ERR_CUSTOMER_SUB_COMMAND, pszSubCommand);
}

/******************** processFlightCommand *******************************/

void processFlightCommand(NodeT **ppRoot
                   , char *pszSubCommand, char *pszRemainingInput)
{
    Flight flight;
    int iQuantity;      // quantity of seats 
    int iScanfCnt;
    int indent = 0;
    NodeT * new;
    // Determine what to do based on the subCommand
    // your code
 	if (strcmp(pszSubCommand, "SHOW") == 0) {
	
	iScanfCnt = sscanf(pszRemainingInput, "%11s", flight.szFlightId);

	if(iScanfCnt < 1) {
		exitError(ERR_SHOW_SUB_COMMAND, pszRemainingInput);
	}
	
	
	new = searchT(*ppRoot, flight.szFlightId);
	
	if(new != NULL)
	printf("    %-10s   %-4s %-4s %-6s %5d   $%5.2lf\n"
            , new->flight.szFlightId
            , new->flight.szFrom
            , new->flight.szDest
            , new->flight.szDepartTm
            , new->flight.iAvailSeatCnt
            , new->flight.dSeatPrice);
	}

	else	if (strcmp(pszSubCommand, "INCREASE") == 0) {

	iScanfCnt = sscanf(pszRemainingInput, "%11s %d", flight.szFlightId, &iQuantity);

	if(iScanfCnt < 2) {
		exitError(ERR_INCREASE_SUB_COMMAND, pszRemainingInput);
	}
	
	new = searchT(*ppRoot, flight.szFlightId);

	if(new != NULL) {
	new->flight.iAvailSeatCnt = new->flight.iAvailSeatCnt + iQuantity;

	printf("\n\tSeats available for flight %s increased by %d\n", new->flight.szFlightId, iQuantity);
	} 
	}
	else	if (strcmp(pszSubCommand, "NEW") == 0) {
	
	iScanfCnt = sscanf(pszRemainingInput, "%10s %3s %3s %5s %4d %10lf"
            , flight.szFlightId
            , flight.szFrom
            , flight.szDest
            , flight.szDepartTm
            , &flight.iAvailSeatCnt
            , &flight.dSeatPrice);
	
	if(iScanfCnt < 6) {
            exitError(ERR_FLIGHT_SUB_COMMAND, pszRemainingInput);
	}

	NodeT * pNew;
	pNew = insertT(*ppRoot, flight);
	
	}
 	
	else	if(strcmp(pszSubCommand, "PPRINT") == 0) {
	
	prettyPrintT(*ppRoot, indent);
	
	}

	else

	printf("\n\t\t\t\t%-10s ***%s\n\n", flight.szFlightId, ERR_FLIGHT_NOT_FOUND);
}

/******************** searchT *********************************************/

NodeT *searchT(NodeT *p, char szMatchFlightId[])
{
    // your code
	if(p == NULL) { 
		return NULL;
	}

	//found it so return p as the result
	if(strcmp(szMatchFlightId, p->flight.szFlightId) == 0) { 
		return p;
	}

	//if p is < then szMatchFlightId, then search left
	//else search right
	//once we either find the node we want OR go past a leaf node, return that result up the call chain
	if(strcmp(szMatchFlightId, p->flight.szFlightId) < 0)
		return searchT(p->pLeft, szMatchFlightId);
	else
		return searchT(p->pRight, szMatchFlightId);

}
