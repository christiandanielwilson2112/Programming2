/***********************************************************************************
cs1713p3.c by Christian Wilson   (skeletal version)
Purpose:
    This program reads flight information and a command file.   It 
    processes the commands against the flight information.
    This file contains the functions that students write.
Command Parameters:
    p3 -f flightFileName -c commandFileName
Input:
    Flight   Stream input file which contains many records defining flights:
                 szFlightId szFrom  szDest  szDepartTm  iAvailSeats dSeatPrice 
                 10s        3s      3s      5s          4d          10lf 

    Command  This is different from the previous assignment.  The file contains 
             text in the form of commands (one command per text line):  
                 CUSTOMER BEGIN cGender   szBirthDt   szEmailAddr    szFullName
                     specifies the beginning of customer request and includes 
                     all the identification information from program 2.
                 CUSTOMER ADDRESS szStreetAddress,szCity,szStateCd,szZipCd
                     specifies the address for a customer (separated by commas)
                 CUSTOMER REQUEST szFlightId iNumSeats
                     specifies a single flight request.  Steps:
                     >	Print the flight ID and requested number of seats
                     >	Lookup the flight ID using a binary search.  If not found,
                        print a warning (but do not terminate your program) and return.
                     >	If found, try to satisfy the entire requested number of seats.
                        If not enough seats,  print a warning and return.
                     >	Print the unit price and cost.
                     >	Accumulate the total cost for this customer
                 CUSTOMER COMPLETE
                     specifies the completion of the list of flight requests 
                     for a customer.
                 FLIGHT INCREASE szFlightId iQuantity
                     increase the available seats for a flight by the specified quantity.
                 FLIGHT SHOW szFlightId    
                     requests a display of a particular flight.  Show all of its information.

Results:
    Prints the Flights prior to sorting
    Prints the Flight after sorting.
    Processes the commands (see above) and shows any errors.
    Prints the resulting Flights
Returns:
    0  normal
    -1 invalid command line syntax
    -2 show usage only
    -3 error during processing, see stderr for more information

Notes:
    p3 -?       will provide the usage information.  In some shells,
                you will have to type p3 -\?

**********************************************************************/
// If compiling using visual studio, tell the compiler not to give its warnings
// about the safety of scanf and printf
#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "cs1713p3.h"

/******************** getFlights **************************************
    int getFlights(Flight flightM[])
Purpose: to scan in flights

Parameters: Flight flightM[]
  
Returns: int i, number of flights
    
Notes: the book on C was very helpful
    
**************************************************************************/
int getFlights(Flight flightM[], char * pszFlightFileName)
{
    char szInputBuffer[100];		// input buffer for reading data
    int i = 0;                      // subscript in flightM
    int iScanfCnt;                  // returned by sscanf
    FILE *pFileFlight;              // Stream Input for Flights data. 

    /* open the Flights stream data file */
    if (pszFlightFileName == NULL)
        exitError(ERR_MISSING_SWITCH, "-i");

    pFileFlight = fopen(pszFlightFileName, "r");
    if (pFileFlight == NULL)
        exitError(ERR_FLIGHT_FILENAME, pszFlightFileName);

    /* get flight information until EOF
    ** fgets returns null when EOF is reached.
    */

    /**** your code ******/
	while(!feof(pFileFlight)) {
	if(fgets(szInputBuffer, 100, pFileFlight) == NULL) 
			continue;

	iScanfCnt = sscanf(szInputBuffer, "%10s %3s %3s %5s %4d %10lf"
	, flightM[i].szFlightId
	, flightM[i].szFrom
	, flightM[i].szDest
	, flightM[i].szDepartTm
	, &flightM[i].iAvailSeatCnt
	, &flightM[i].dSeatPrice);
	i++;
}
    fclose(pFileFlight);
    return i;

}
/******************** sortFlights **************************************
    void sortFlights(Flight flightM[], int iFlightCnt)
Purpose: bubble sort the flight from least to greatest

Parameters: Flight flightM[], int iFlightCnt
  
Returns: void
    
Notes: the book on C was very helpful
    
**************************************************************************/
void sortFlights(Flight flightM[], int iFlightCnt)
{
    /**** your code ******/
	//inner and outer loop iterations
	int outer = 0, inner = 0;

	//outer loop iterates iFlightCnt -1 times
	for(outer = 0; outer < iFlightCnt - 1; outer++) {
		//for each iteration of outer loop, inner loop iterates iFlightCnt - 1 - outer times
		//each iteration of outer loop has nth largest element correctly sorted in the iFlightCnt - n position
		for(inner = 0; inner < (iFlightCnt -1 - outer); inner++) {
		//compare flightM[inner] and flightM[inner + 1]
		//swap if flightM[inner] is larger
		if(strcmp(flightM[inner].szFlightId, flightM[inner + 1].szFlightId) > 0) {
		Flight temp;
		temp = flightM[inner];
		flightM[inner] = flightM[inner + 1];
		flightM[inner + 1] = temp;
			}
		}
	}
}

/******************** printFlights **************************************
    void printFlights(char *pszHeading, Flight flightM[], int iFlightCnt)
Purpose: print flights

Parameters: char *pszHeading, Flight flightM[], int iFlightCnt
  
Returns: void
    
Notes: the book on C was very helpful
    
**************************************************************************/
void printFlights(char *pszHeading, Flight flightM[], int iFlightCnt)
{
    int i;
    printf("%s\n", pszHeading);
    printf("    %-10s   %-4s %-4s %-6s %-6s  %-10s\n"
        , "Flight Id", "From", "Dest", "Depart", "Avail", "Unit Price");

    for (i = 0; i < iFlightCnt; i++)
    {
        printf("    %-10s   %-4s %-4s %-6s %5d   %10.2lf\n"
            , flightM[i].szFlightId
            , flightM[i].szFrom
            , flightM[i].szDest
            , flightM[i].szDepartTm
            , flightM[i].iAvailSeatCnt
            , flightM[i].dSeatPrice);
    }
}

/********************processCustomerCommand *****************************
    void processCustomerCommand(Flight flightM[], int iFlightCnt
     , char *pszSubCommand, char *pszRemainingInput
     , Customer *pCustomer, double *pdCustomerRequestTotalCost )
Purpose:
    Processes the subcommands associated with the CUSTOMER command:
                 CUSTOMER BEGIN cGender   szBirthDt   szEmailAddr    szFullName
                     specifies the beginning of customer request and includes 
                     all the identification information from program 2.
                 CUSTOMER ADDRESS szStreetAddress,szCity,szStateCd,szZipCd
                     specifies the address for a customer (separated by commas)
                 CUSTOMER REQUEST szFlightId iNumSeats
                     specifies a single flight request.  Steps:
                     >	Print the flight ID and requested number of seats
                     >	Lookup the flight ID using a binary search.  If 
                        not found, print a warning (but do not terminate your 
                        program) and return.
                     >	If found, try to satisfy the entire requested number 
                        of seats.  If not enough seats, print a warning and 
                        return.
                     >	Print the unit price and cost.
                     >	Accumulate the total cost for this customer

                 CUSTOMER COMPLETE
                     specifies the completion of the list of flight requests 
                     for a customer.
Parameters:
    I/O Flight flightM[]              Array of flights
    I   int   iFlightCnt              Number of elments in flightM[]
    I   char  *pszSubCommand          Should be BEGIN, ADDRESS, REQUEST or COMPLETE
    I   char  *pzRemainingInput       Points to the remaining characters in the input
                                      line (i.e., the characters that following the
                                      subcommand).
    I/O Customer *pCustomer           The BEGIN subcommand begins a new customer.  The 
                                      customer's Request Total Cost must be set to 0.
    I/O double   *pdCustomerRequestTotalCost     The customer total cost.  This changes depending
                                      on the subcommand:
                                          BEGIN - set to 0
                                          REQUEST - add the cost  (unless there is a warning) 
Notes: the book on C was very helpful

**************************************************************************/
void processCustomerCommand(Flight flightM[], int iFlightCnt
    , char *pszSubCommand, char *pszRemainingInput
    , Customer *pCustomer, double *pdCustomerRequestTotalCost)
{
    int iScanfCnt;
    FlightRequest flightRequest;

    // Determine what to do based on the subCommand
    if (strcmp(pszSubCommand, "BEGIN") == 0)
    {
        // get the Customer Identification Information
        // your code
	iScanfCnt = sscanf(pszRemainingInput, "%c %11s %51s %31[^\n]\n"
			, &pCustomer->cGender
			, pCustomer->szBirthDt
			, pCustomer->szEmailAddr
			, pCustomer->szFullName);
			

        if (iScanfCnt < 4)
            exitError(ERR_CUSTOMER_ID_DATA, pszRemainingInput);

    }
    else if (strcmp(pszSubCommand, "COMPLETE") == 0)
    {        
	printf("\t\t\t\t\t\t TOTAL COST: %5.2lf\n", *pdCustomerRequestTotalCost);
	*pdCustomerRequestTotalCost = 0;
	printf("*************************************************************\n");
    }
    else if (strcmp(pszSubCommand, "ADDRESS") == 0)
    {
        // get the postal address 
        // your code 
	iScanfCnt = sscanf(pszRemainingInput,"%31[^,],%21[^,],%3[^,],%6s\n"
			, pCustomer->szStreetAddress
			, pCustomer->szCity
			, pCustomer->szStateCd
			, pCustomer->szZipCd);

	printf("********************  FLIGHT RESERVATION REQUEST  *******************\n");

	printf("%s %s (%c %s)\n"
			, pCustomer->szEmailAddr
			, pCustomer->szFullName
			, pCustomer->cGender
			, pCustomer->szBirthDt);
        
        printf("%s\n", pCustomer->szStreetAddress);
        
        printf("%s, %s %s\n", pCustomer->szCity
               , pCustomer->szStateCd
               , pCustomer->szZipCd);

        printf("\t\t\t\t%-10s %8s %10s %8s\n"
            , "Flight Id"
            , "Quantity"
            , "Unit Price"
            , "Cost");
    }
    else if (strcmp(pszSubCommand, "REQUEST") == 0)
    {
        int i;
        // get a flight request
        // your code
	for(i = 0; i < iFlightCnt; i++) {
        iScanfCnt = sscanf(pszRemainingInput,"%11s %5d"
			, flightRequest.szFlightId
			, &flightRequest.iRequestSeats);
		}

        // find the flight in the array
        i = search(flightM, iFlightCnt, flightRequest.szFlightId);

        // your code
        double cost = flightM[i].dSeatPrice * flightRequest.iRequestSeats;
        
        if (i == -1)
            printf("\t\t\t\t%-10s %8d *** %s\n"
                   , flightRequest.szFlightId
                   , flightRequest.iRequestSeats, ERR_FLIGHT_NOT_FOUND);
        else
            printf("\t\t\t\t%-10s %8d %10.2lf %8.2lf\n"
                   , flightRequest.szFlightId
                   , flightRequest.iRequestSeats
                   , flightM[i].dSeatPrice
                   , cost);

	*pdCustomerRequestTotalCost += cost;
  
    }
    else printf("   *** %s %s\n", ERR_CUSTOMER_SUB_COMMAND, pszSubCommand);
}
/********************processFlightCommand *****************************
    void processFlightCommand(Flight flightM[], int iFlightCnt
         , char *pszSubCommand, char *pszRemainingInput)
Purpose:
    Processes the subcommands associated with the FLIGHT command:
        FLIGHT INCREASE szFlightId iQuantity
               increase the available seats for a flight by the specified quantity.
        FLIGHT SHOW szFlightId    
               requests a display of a particular flight.  Show all of its information.
Parameters:
    I/O Flight flightM[]              Array of flights
    I   int   iFlightCnt              Number of elments in flightM[]
    I   char  *pszSubCommand          Should be RECEIVE or SHOW
    I   char  *pzRemainingInput       Points to the remaining characters in the input
                                      line (i.e., the characters that following the
                                      subcommand).
Notes: the book on C was very helpful

**************************************************************************/
void processFlightCommand(Flight flightM[], int iFlightCnt
                             , char *pszSubCommand, char *pszRemainingInput)
{
    Flight flight;
    int iQuantity;      // quantity of seats 
    int iScanfCnt;
    int i;
  
    // Determine what to do based on the subCommand
    // your code
 	if (strcmp(pszSubCommand, "SHOW") == 0)
	{	
	iScanfCnt = sscanf(pszRemainingInput, "%11s\n", flight.szFlightId);
	if(strcmp(flightM[i].szFlightId, flight.szFlightId) == 0)
	printf("    %-10s   %-4s %-4s %-6s %5d   %10.2lf\n"
            , flightM[i].szFlightId
            , flightM[i].szFrom
            , flightM[i].szDest
            , flightM[i].szDepartTm
            , flightM[i].iAvailSeatCnt
            , flightM[i].dSeatPrice);
	}
	else	if (strcmp(pszSubCommand, "INCREASE") == 0)
    	{
	iScanfCnt = sscanf(pszRemainingInput, "%11s %d\n", flight.szFlightId, &iQuantity);
	flightM[i].iAvailSeatCnt += iQuantity;
	}
}
/******************** search *****************************
    int search(Flight flightM[], int iFlightCnt, char *pszMatchFlightId)
Purpose: binarily searches for the flight and matches it to flight file
    
Parameters:
    I   Flight flightM[]               Array of flights
    I   int   iFlightCnt               Number of elments in flightM[]
    I   char *pszMatchFlightId         Flight Id to find in the array
Returns:
    >= 0   subscript of where the match value was found
    -1     not found
Notes: the book on C was helpful

**************************************************************************/
int search(Flight flightM[], int iFlightCnt, char *pszMatchFlightId)
{
    // your code

    //index variables
    int loIndex = 0;
    int checkIndex;
    int hiIndex = iFlightCnt - 1;
    
    while (loIndex <= hiIndex) {
        checkIndex = (hiIndex + loIndex) / 2;
        if (strcmp(flightM[checkIndex].szFlightId, pszMatchFlightId) == 0)
            return checkIndex;
        else if (strcmp(flightM[checkIndex].szFlightId, pszMatchFlightId) > 0)
            hiIndex = checkIndex - 1;
        else if (strcmp(flightM[checkIndex].szFlightId, pszMatchFlightId) < 0)
            loIndex = checkIndex + 1;
        if (loIndex > hiIndex)
            return -1;
    }
}
