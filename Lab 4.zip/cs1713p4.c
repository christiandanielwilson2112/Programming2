/***********************************************************************************
cs1713p4.c by Christian Wilson   (skeletal version)
Purpose:
    This program reads flight information and a command file.   It 
    processes the commands against the flight information.
    This file contains the functions that students write.
Command Parameters:
    p4 -f flightFileName -c commandFileName
Input:
    Flight   Stream input file which contains many records defining flights:
                 szFlightId szFrom  szDest  szDepartTm  iAvailSeats dSeatPrice 
                 10s        3s      3s      5s          4d          10lf 

    Command  This is different from the previous assignment.  The file contains 
             text in the form of commands (one command per text line):  
                 CUSTOMER BEGIN cGender   szBirthDt   szEmailAddr    szFullName
                     specifies the beginning of customer request and includes 
                     all the identification information from program 2.
                 CUSTOMER ADDRESS szStreetAddress,szCity,szStateCd,szZipCd
                     specifies the address for a customer (separated by commas)
                 CUSTOMER REQUEST szFlightId iNumSeats
                     specifies a single flight request.  Steps:
                     >	Print the flight ID and requested number of seats
                     >	Lookup the flight ID using a binary search.  If not found,
                        print a warning (but do not terminate your program) and return.
                     >	If found, try to satisfy the entire requested number of seats.
                        If not enough seats,  print a warning and return.
                     >	Print the unit price and cost.
                     >	Accumulate the total cost for this customer
                 CUSTOMER COMPLETE
                     specifies the completion of the list of flight requests 
                     for a customer.
                 FLIGHT INCREASE szFlightId iQuantity
                     increase the available seats for a flight by the specified quantity.
                 FLIGHT SHOW szFlightId    
                     requests a display of a particular flight.  Show all of its information.

Results:
    Prints the Flights prior to sorting
    Prints the Flight after sorting.
    Processes the commands (see above) and shows any errors.
    Prints the resulting Flights
Returns:
    0  normal
    -1 invalid command line syntax
    -2 show usage only
    -3 error during processing, see stderr for more information

Notes:
    p4 -?       will provide the usage information.  In some shells,
                you will have to type p4 -\?

**********************************************************************/
// If compiling using visual studio, tell the compiler not to give its warnings
// about the safety of scanf and printf
#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "cs1713p4.h"

/******************** insertLL ******************************************/
Node *insertLL(Node **ppHead, Flight flight)
{ 
    /**** your code ******/
	//1. search for where to insert new node
	Node * prevNode = NULL;
	searchLL(*ppHead, flight.szFlightId, &prevNode);
	
	//2. copy new node's contents to a newly allocated node
	Node * newNode = allocateNode(flight);
	if(newNode == NULL) {
		return NULL;
	}
	
	//3a if prevNode is NULL then new node is new front of list
	if(prevNode == NULL) {
		newNode->pNext = *ppHead; //new node points to previous list head
		*ppHead = newNode;//new node is the new head; this is why we need a pointer to the head pointer
	} else {
		//3b else new node's next will point to prevNode->next and prevNode->next will point to new node
		newNode->pNext = prevNode->pNext;
 		prevNode->pNext = newNode;
	}
	return newNode;

}

/******************** printFlights ***************************************/
void printFlights(char *pszHeading, Node *pHead) 
{
    printf("%s\n", pszHeading);
    printf("    %-10s   %-4s %-4s %-6s %-6s  %-10s\n"
        , "Flight Id", "From", "Dest", "Depart", "Avail", "Unit Price");

    while(pHead != NULL)
    {
        printf("    %-10s   %-4s %-4s %-6s %5d   $%10.2lf\n"
            , pHead->flight.szFlightId
            , pHead->flight.szFrom
            , pHead->flight.szDest
            , pHead->flight.szDepartTm
            , pHead->flight.iAvailSeatCnt
            , pHead->flight.dSeatPrice);

	    pHead = pHead->pNext;
    }
}

/********************processCustomerCommand ******************************/
void processCustomerCommand(Node **ppHead
    , char *pszSubCommand, char *pszRemainingInput
    , Customer *pCustomer, double *pdCustomerRequestTotalCost)
{ 
    int iScanfCnt;
    FlightRequest flightRequest;

   // Determine what to do based on the subCommand
    if (strcmp(pszSubCommand, "BEGIN") == 0)
    {
        // get the Customer Identification Information
        // your code
	iScanfCnt = sscanf(pszRemainingInput, "%c %11s %51s %31[^\n]\n"
			, &pCustomer->cGender
			, pCustomer->szBirthDt
			, pCustomer->szEmailAddr
			, pCustomer->szFullName);
			
        if (iScanfCnt < 4)
            exitError(ERR_CUSTOMER_ID_DATA, pszRemainingInput);

    }
    else if (strcmp(pszSubCommand, "COMPLETE") == 0)
    {        
	printf("\t\t\t\t\t\t TOTAL COST: $%5.2lf\n", *pdCustomerRequestTotalCost);
	*pdCustomerRequestTotalCost = 0;
	printf("*************************************************************\n");
    }
    else if (strcmp(pszSubCommand, "ADDRESS") == 0)
    {
        // get the postal address 
        // your code 
	iScanfCnt = sscanf(pszRemainingInput,"%31[^,],%21[^,],%3[^,],%6s\n"
			, pCustomer->szStreetAddress
			, pCustomer->szCity
			, pCustomer->szStateCd
			, pCustomer->szZipCd);

	printf("********************  FLIGHT RESERVATION REQUEST  *******************\n");

	printf("%s %s (%c %s)\n"
			, pCustomer->szEmailAddr
			, pCustomer->szFullName
			, pCustomer->cGender
			, pCustomer->szBirthDt);
        
        printf("%s\n", pCustomer->szStreetAddress);
        
        printf("%s, %s %s\n", pCustomer->szCity
               , pCustomer->szStateCd
               , pCustomer->szZipCd);

        printf("\t\t\t\t%-10s %8s %10s %8s\n"
            , "Flight Id"
            , "Quantity"
            , "Unit Price"
            , "Cost");
    }
    else if (strcmp(pszSubCommand, "REQUEST") == 0)
    {
        // get a flight request
        // your code
        iScanfCnt = sscanf(pszRemainingInput,"%11s %5d"
			, flightRequest.szFlightId
			, &flightRequest.iRequestSeats);
		

        // find the flight in the array
	Node * precedes = NULL; 
	Node * new = searchLL(*ppHead, flightRequest.szFlightId, &precedes);

        // your code
        double cost = (*ppHead)->flight.dSeatPrice * flightRequest.iRequestSeats;
        
        if(new == NULL)
            printf("\t\t\t\t%-10s %8d *** %s\n"
                   , flightRequest.szFlightId
                   , flightRequest.iRequestSeats, ERR_FLIGHT_NOT_FOUND);
        else
            printf("\t\t\t\t%-10s %8d $%10.2lf $%8.2lf\n"
                   , flightRequest.szFlightId
                   , flightRequest.iRequestSeats
                   , (*ppHead)->flight.dSeatPrice
                   , cost);

	*pdCustomerRequestTotalCost += cost;
  
    }
    else printf("   *** %s %s\n", ERR_CUSTOMER_SUB_COMMAND, pszSubCommand);
}

/******************** processFlightCommand *******************************/

void processFlightCommand(Node **ppHead
                   , char *pszSubCommand, char *pszRemainingInput)
{
    Flight flight;
    int iQuantity;      // quantity of seats 
    int iScanfCnt;
  
    // Determine what to do based on the subCommand
    // your code
 	if (strcmp(pszSubCommand, "SHOW") == 0) {
	
	iScanfCnt = sscanf(pszRemainingInput, "%11s", flight.szFlightId);

	if(iScanfCnt < 1) {
		exitError(ERR_SHOW_SUB_COMMAND, pszRemainingInput);
	}
	
	if(strcmp((*ppHead)->flight.szFlightId, flight.szFlightId) == 0)
	printf("    %-10s   %-4s %-4s %-6s %5d   $%10.2lf\n"
            , (*ppHead)->flight.szFlightId
            , (*ppHead)->flight.szFrom
            , (*ppHead)->flight.szDest
            , (*ppHead)->flight.szDepartTm
            , (*ppHead)->flight.iAvailSeatCnt
            , (*ppHead)->flight.dSeatPrice);
	}

	else	if (strcmp(pszSubCommand, "INCREASE") == 0) {

	iScanfCnt = sscanf(pszRemainingInput, "%11s %d", flight.szFlightId, &iQuantity);

	if(iScanfCnt < 2) {
		exitError(ERR_INCREASE_SUB_COMMAND, pszRemainingInput);
	}

	(*ppHead)->flight.iAvailSeatCnt = (*ppHead)->flight.iAvailSeatCnt + iQuantity;

	printf("\n\tSeats available for flight %s increased by %d\n",
		(*ppHead)->flight.szFlightId, iQuantity);
	} 

	else	if (strcmp(pszSubCommand, "NEW") == 0) {
	
	iScanfCnt = sscanf(pszRemainingInput, "%10s %3s %3s %5s %4d %10lf"
            , flight.szFlightId
            , flight.szFrom
            , flight.szDest
            , flight.szDepartTm
            , &flight.iAvailSeatCnt
            , &flight.dSeatPrice);
	
	if(iScanfCnt < 6) {
            exitError(ERR_FLIGHT_SUB_COMMAND, pszRemainingInput);
	}

	Node * pNew;
	pNew = insertLL(&(*ppHead), flight);
	
	}
 	
	else

	printf("\n\t\t\t\t%-10s ***%s\n\n", flight.szFlightId, ERR_FLIGHT_NOT_FOUND);
}

/******************** search *********************************************/

Node *searchLL(Node *pHead, char szMatchFlightId[], Node **ppPrecedes)
{
    // your code
	*ppPrecedes = NULL;//this is our chase pointer
	//return if list is empty
	if(pHead == NULL)
		return NULL;
	
	while(pHead != NULL) {
		//ppPrecedes tracks the largest value that is smaller than szMatchFlightId which is where insertion will occur
		if(strcmp(pHead->flight.szFlightId, szMatchFlightId) < 0) {
			*ppPrecedes = pHead;
		}
		
		//see if we found our search value. if so, return pointer to it
		if(strcmp(pHead->flight.szFlightId, szMatchFlightId) == 0) {
			return pHead;
		}
		
		//increment p to next node
		pHead = pHead->pNext;
	}
	//did not find szMatchFlightId so return NULL
	return NULL;

}
